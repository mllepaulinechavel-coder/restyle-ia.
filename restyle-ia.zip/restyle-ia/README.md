# Restyle IA

Application web : vous envoyez une courte vidéo et un prompt, Runway (modèle gen4_aleph) la restylise.

## Installation
1. Installez Node.js 18 ou plus récent.
2. Créez un compte sur https://dev.runwayml.com et générez une clé API (des crédits payants sont nécessaires).
3. Dans ce dossier :
   ```
   npm install
   cp .env.example .env     # puis collez votre clé dans .env
   npm start
   ```
4. Ouvrez http://localhost:3000

## Limites
- Vidéos courtes (quelques secondes, 10 Mo max) : la vidéo est envoyée en base64.
- Pour des fichiers plus gros, hébergez la vidéo (URL HTTPS) et passez cette URL dans `videoUri`.
- Ne publiez jamais votre fichier `.env`.
- Vérifiez les noms de paramètres et les tarifs dans la doc officielle de Runway.
